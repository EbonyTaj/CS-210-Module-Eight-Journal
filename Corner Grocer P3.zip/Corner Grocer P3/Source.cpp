// Developer: Ebony Anderson
// Date: February 24, 2024
// Purpose: This program implements an item-tracking application for the Corner Grocer.
//          It reads text records of items purchased throughout the day,
//          analyzes the data, and provides functionalities to query item frequencies,
//          print frequency information, generate a histogram, and create a backup file.

#include <iostream>
#include <fstream>
#include <map>
#include <string>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;
    std::string inputFile;
    std::string outputFile;

public:
    ItemTracker(const std::string& input, const std::string& output)
        : inputFile(input), outputFile(output) {}

    void loadInputFile() {
        std::ifstream file(inputFile);
        std::string item;
        while (file >> item) {
            itemFrequency[item]++;
        }
        file.close();
    }

    void displayMenu() {
        std::cout << "Menu Options:\n"
            << "1. Search for a specific item\n"
            << "2. Print list of item frequencies\n"
            << "3. Print item histogram\n"
            << "4. Exit\n";
    }

    void searchItemFrequency(const std::string& item) {
        std::cout << "Frequency of " << item << ": " << itemFrequency[item] << std::endl;
    }

    void printItemFrequency() {
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << " " << pair.second << std::endl;
        }
    }

    void printItemHistogram() {
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << std::endl;
        }
    }

    void backupData() {
        std::ofstream backup(outputFile);
        for (const auto& pair : itemFrequency) {
            backup << pair.first << " " << pair.second << std::endl;
        }
        backup.close();
    }
};

int main() {
    ItemTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");
    tracker.loadInputFile();

    int choice;
    std::string searchItem;

    do {
        tracker.displayMenu();
        std::cout << "Enter your choice (1-4): ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter the item you wish to search for: ";
            std::cin >> searchItem;
            tracker.searchItemFrequency(searchItem);
            break;
        case 2:
            tracker.printItemFrequency();
            break;
        case 3:
            tracker.printItemHistogram();
            break;
        case 4:
            tracker.backupData();
            std::cout << "Exiting the program. Data backed up to frequency.dat.\n";
            break;
        default:
            std::cout << "Invalid choice. Please enter a number between 1 and 4.\n";
        }
    } while (choice != 4);

    return 0;
}
